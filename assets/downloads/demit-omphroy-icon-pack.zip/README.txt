Hidden in the Mural: icon pack
Drawings by Demit Omphroy, from "The Characters of San Francisco" mural at 384 Post, Union Square.

24 hand-drawn objects, as SVG (scalable) and PNG (1024 px, transparent background).

You're welcome to use these for personal, non-commercial things: phone wallpapers, stickers, journaling, sharing on social (please tag @demit).
Please don't sell them, use them in logos or products, or claim them as your own.

Artwork (c) 2026 Demit Omphroy. All rights reserved.
demitomphroy.com  ·  instagram.com/demit
